var helicopter,helicopterImage
var package
var redbox

function setup() {
  createCanvas(600, 600);
  helicopter = createSprite(200,100,50,50)
  helicopter.addImage("helicopter", helicopter.png)
  
  package = createSprite(200,100,30,30)
  package.addImage("package",package.png)
  
  redbox=createSprite(200,0,50,240,100)
  redbox.addImage("redbox",  redbox.svg)
}

function draw() {
  background(220);
  helicopter.depth=package.depth+1
  if(keyDown(DOWN_ARROW)){
  package.velocityY=-2
  package.collide(redbox)
    
  
  }
}